const player = document.getElementById('player');
    const gameCont = document.querySelector('.game-cont');
    let posX = 300;
    const velocidade = 5;

    let andandoDireita = false;
    let andandoEsquerda = false;
    let naPrimeira = false;
    let naUltima = false;

    window.addEventListener('keydown', (e) => {
      if (e.key === 'd') andandoDireita = true;
      if (e.key === 'a') andandoEsquerda = true;
      if (e.key === 'w') naPrimeira = true;
      if (e.key === 's') naUltima = true;
    });

    window.addEventListener('keyup', (e) => {
      if (e.key === 'd') andandoDireita = false;
      if (e.key === 'a') andandoEsquerda = false;
      if (e.key === 'w') naPrimeira = false;
      if (e.key === 's') naUltima = false;
    });

    let vidas = 3;
    const hearts = [
      document.getElementById('hh1'),
      document.getElementById('hh2'),
      document.getElementById('hh3')
    ];

    // Estados possíveis: 'normal', 'hit', 'morto'
    let playerStatus = 'normal';

    function perdeVida() {
      if (playerStatus === 'morto' || playerStatus === 'hit') return;
      document.body.style.filter = "brightness(0.5) sepia(1) hue-rotate(-50deg) saturate(4)";
      setTimeout(() => {
        document.body.style.filter = "";
      }, 200);

      vidas--;
      if (vidas >= 0 && hearts[vidas]) {
        hearts[vidas].style.visibility = 'hidden';
        playerStatus = 'hit';
        player.style.backgroundImage = "url('cuphead/hit.png')";
        setTimeout(() => {
          if (playerStatus !== 'morto') {
            playerStatus = 'normal';
            player.style.backgroundImage = "url('cuphead/normal.png')";
          }
        }, 200);
      }
      if (vidas <= 0) {
        playerStatus = 'morto';
        player.style.backgroundImage = "url('cuphead/morte.png')";
        mostrarGameOver();
      }
    }

    let tempo = 0;
    let timerInterval = setInterval(() => {
      tempo++;
      document.getElementById('timer').textContent = tempo + 's';
    }, 1000);

    function mostrarGameOver() {
      document.getElementById('gameover-screen').style.display = 'flex';
      clearInterval(timerInterval);

      let pontuacao = document.getElementById('pontuacao-final');
      if (!pontuacao) {
        pontuacao = document.createElement('h3');
        pontuacao.id = 'pontuacao-final';
        pontuacao.style.color = 'white';
        pontuacao.style.fontFamily = 'Minecraftia';
        pontuacao.style.marginTop = '10px';
        document.getElementById('gameover-screen').appendChild(pontuacao);
      }
      pontuacao.textContent = `Tempo: ${tempo}s`;
      window.addEventListener('mousedown', reiniciarJogo, { once: true });
    }

    function reiniciarJogo() {
      location.reload();
    }


    const inimigos = [];
    const inimigosImgs = ['Imgs/fireball.png', 'Imgs/tnt.png'];

    function criarInimigo() {
      const inimigo = document.createElement('div');
      inimigo.className = 'inimigo';
      const img = inimigosImgs[Math.floor(Math.random() * inimigosImgs.length)];
      inimigo.style.backgroundImage = `url('${img}')`;

      const gameWidth = gameCont.offsetWidth;
      const gameHeight = gameCont.offsetHeight;

      const borda = Math.floor(Math.random() * 4);

      let x, y, velX = 0, velY = 0;
      const speed = 4;

      switch (borda) {
        case 0:
          x = Math.random() * (gameWidth - 40);
          y = 0;
          velX = 0;
          velY = speed;
          break;
        case 1:
          x = gameWidth - 40;
          y = Math.random() * (gameHeight - 40);
          velX = -speed;
          velY = 0;
          break;
        case 2: 
          x = Math.random() * (gameWidth - 40);
          y = gameHeight - 40;
          velX = 0;
          velY = -speed;
          break;
        case 3:
          x = 0;
          y = Math.random() * (gameHeight - 40);
          velX = speed;
          velY = 0;
          break;
      }

      inimigo.style.left = x + 'px';
      inimigo.style.top = y + 'px';

      gameCont.appendChild(inimigo);

      inimigos.push({ el: inimigo, x, y, velX, velY, width: 40, height: 40 });
    }

    function colisaoElemento(a, b) {
      const ra = a.getBoundingClientRect();
      const rb = b.getBoundingClientRect();
      return !(
        ra.right < rb.left ||
        ra.left > rb.right ||
        ra.bottom < rb.top ||
        ra.top > rb.bottom
      );
    }

    function atualizarInimigos() {
      for (let i = inimigos.length - 1; i >= 0; i--) {
        let inim = inimigos[i];
        inim.x += inim.velX;
        inim.y += inim.velY;

        if (
          inim.x < -inim.width ||
          inim.x > gameCont.offsetWidth ||
          inim.y < -inim.height ||
          inim.y > gameCont.offsetHeight
        ) {
          inim.el.remove();
          inimigos.splice(i, 1);
          continue;
        }

        inim.el.style.left = inim.x + 'px';
        inim.el.style.top = inim.y + 'px';

        if (colisaoElemento(player, inim.el)) {
          perdeVida();
          inim.el.remove();
          inimigos.splice(i, 1);
        }
      }
    }

    setInterval(criarInimigo, 500);

    function atualizar() {
      if (playerStatus === 'normal') {
        if (andandoDireita) {
          posX += velocidade;
          player.style.backgroundImage = "url('cuphead/direita.png')";
        }
        if (andandoEsquerda) {
          posX -= velocidade;
          player.style.backgroundImage = "url('cuphead/esquerda.png')";
        }
        if (!andandoDireita && !andandoEsquerda) {
          player.style.backgroundImage = "url('cuphead/normal.png')";
        }
        if (naUltima && andandoDireita) {
          player.style.backgroundImage = "url('cuphead/baixoD.png')";
        }
        if (naUltima && andandoEsquerda) {
          player.style.backgroundImage = "url('cuphead/baixeE.png')";
        }
        if (naUltima && !andandoDireita && !andandoEsquerda) {
          player.style.backgroundImage = "url('cuphead/baixoD.png')";
        }
        if (naPrimeira && andandoDireita) {
          player.style.backgroundImage = "url('cuphead/puloD.png')";
        }
        if (naPrimeira && andandoEsquerda) {
          player.style.backgroundImage = "url('cuphead/puloE.png')";
        }
        if (naPrimeira && !andandoDireita && !andandoEsquerda) {
          player.style.backgroundImage = "url('cuphead/puloD.png')";
        }
      }

      const gameWidth = gameCont.offsetWidth;
      const playerWidth = player.offsetWidth;
      if (posX < 0) posX = 0;
      if (posX > gameWidth - playerWidth) posX = gameWidth - playerWidth;

      player.style.left = posX + 'px';

      if (naPrimeira) {
        player.style.bottom = '54%';
      } else if (naUltima) {
        player.style.bottom = '20%';
      } else {
        player.style.bottom = '37.5%';
      }

      if (naUltima) {
        player.style.transform = 'scaleX(1.3) scaleY(0.5)';
        player.style.bottom = '18%';
      } else {
        player.style.transform = 'scale(1)';
      }

      atualizarInimigos();

      requestAnimationFrame(atualizar);
    }

    atualizar();
